<?php

defined('_JEXEC') or die('Direct Access to ' . basename(__FILE__) . ' is not allowed.');


/**
 *
 * @author Akbar Pardayev
 * @version $Id: click_uz.php$
 * @package VirtueMart
 * @subpackage payment
 * @copyright Copyright (C) CLICK LLC - All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 */

define('CLICK_ACTION_PREPARE', 0);
define('CLICK_ACTION_COMPLETE', 1);

if (!class_exists('vmPSPlugin'))
    require(VMPATH_PLUGINLIBS . DS . 'vmpsplugin.php');

class plgVmPaymentClick_Uz extends vmPSPlugin
{

    private $payment_url = 'https://my.click.uz/services/pay';

    function __construct(&$subject, $config)
    {

        parent::__construct($subject, $config);

        $this->_loggable = true;
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';

        $varsToPush = array(
            'click_uz_merchant_id' => array('', 'int'),
            'click_uz_merchant_user_id' => array('', 'int'),
            'click_uz_service_id' => array('', 'int'),
            'click_uz_secret_key' => array('', 'char'),
            'payment_currency' => array('', 'int'),
        );
        $this->addVarsToPushCore($varsToPush, 1);
        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);

    }


    public function getVmPluginCreateTableSQL()
    {

        return $this->createTableSQL('Payment CLICK Uzbekistan Table');
    }

    function getTableSQLFields()
    {

        $SQLfields = array(
            'id' => 'int(11) unsigned NOT NULL AUTO_INCREMENT ',
            'virtuemart_order_id' => 'int(11) UNSIGNED',
            'order_number' => 'char(32)',
            'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
            'payment_name' => 'char(255) NOT NULL DEFAULT \'\' ',
            'payment_order_total' => 'decimal(15,5) NOT NULL DEFAULT \'0.00000\' ',
            'payment_currency' => 'char(3) ',
            'click_response' => 'varchar(255)  ',
            'click_paydoc_id' => 'int(11) UNSIGNED ',
            'click_trans_id' => 'int(11) UNSIGNED '
        );
        return $SQLfields;
    }

    function plgVmConfirmedOrder($cart, $order)
    {

        if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }

        if (!class_exists('VirtueMartModelCurrency'))
            require(VMPATH_ADMIN . DS . 'models' . DS . 'currency.php');

        $new_status = '';

        $paymentCurrency = CurrencyDisplay::getInstance($method->payment_currency);
        $totalInPaymentCurrency = round($paymentCurrency->convertCurrencyTo($method->payment_currency, $order['details']['BT']->order_total, false), 2);


        $merchant_id = $method->click_uz_merchant_id;
        $merchant_user_id = $method->click_uz_merchant_user_id;
        $service_id = $method->click_uz_service_id;
        $return_url = JRoute::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id . "&o_id={$order['details']['BT']->order_number}");

        $post_variables = array(
            'merchant_id' => $merchant_id,
            'merchant_user_id' => $merchant_user_id,
            'service_id' => $service_id,
            'transaction_param' => $order['details']['BT']->order_number,
            'amount' => number_format($totalInPaymentCurrency, 0, '.', ''),
            'return_url' => $return_url
        );
        // add html form
        $html = '<div style="margin: auto; text-align: center;">';
        $html .= '<form action="' . $this->payment_url . '" method="get" id="vmPaymentForm" >';
        foreach ($post_variables as $name => $value) {
            $html .= '<input type="hidden" name="' . $name . '" value="' . htmlspecialchars($value) . '" />';
        }
        $html .= '<input type="submit" id="click_uz_submit" class="vm-button-correct" style="display:none" value="' . vmText::_('VMPAYMENT_CLICKUZ_BUTTON_MESSAGE') . '" />';
        $html .= '</form></div><br />';

        vmJsApi::addJScript('vm.paymentFormAutoSubmit', '
  			jQuery(document).ready(function($){
   				jQuery("body").addClass("vmLoading");
  				var msg="' . vmText::_('VMPAYMENT_CLICKUZ_REDIRECT_MESSAGE') . '";
   				jQuery("body").append("<div class=\"vmLoadingDiv\"><div class=\"vmLoadingDivMsg\">"+msg+"</div></div>");
    			jQuery("#vmPaymentForm").submit();
    			window.setTimeout("jQuery(\'.vmLoadingDiv\').hide();",5000);
    			window.setTimeout("jQuery(\'#click_uz_submit\').show();", 5000);
			})
		');

        return $this->processConfirmedOrderPaymentResponse(2, $cart, $order, $html, $this->renderPluginName($method, $order), $new_status);
    }

    function plgVmOnPaymentResponseReceived(&$html)
    {

        $virtuemart_paymentmethod_id = vRequest::getInt('pm', 0);

        $order_number = vRequest::getVar('on', 0);  //?

        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }

        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        if (!class_exists('VirtueMartCart'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
        if (!class_exists('shopFunctionsF'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
        // setup response html
        vmLanguage::loadJLang('com_virtuemart');

        $modelOrder = VmModel::getModel('orders');

        $data = vRequest::getRequest();

        if (!empty($data)) {
            vmdebug('plgVmOnPaymentResponseReceived', $data);
            $order_number = $data['o_id'];

            $virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($order_number);

            if ($virtuemart_order_id) {
                $order = $modelOrder->getOrder($virtuemart_order_id);

                $payment_name = $this->renderPluginName($method);

                $order['customer_notified'] = 1;

                $order['order_status'] = $data['payment_status'] == 2 ? 'C' : 'X';

                $order['comments'] = vmText::sprintf('VMPAYMENT_CLICKUZ_PAYMENT_STATUS_CONFIRMED', $order_number);

                $nb_history = count($order['history']);

//                if ($order['history'][$nb_history - 1]->order_status_code != $order['order_status']) {
//                    $modelOrder->updateStatusForOneOrder($virtuemart_order_id, $order, true);
//                }

                $payment_currency = CurrencyDisplay::getInstance($method->payment_currency);

                $data['order_number'] = $order_number;
                $data['total'] = $customer_total = (number_format((float)$order['details']['BT']->order_total, 2, '.', ''));
                $data['currency_code'] = CurrencyDisplay::getInstance($method->payment_currency)->getSymbol();
                $data['status'] = $this->_getStatusName($order['details']['BT']->order_status_code);

                $html = $this->_getPaymentResponseHtml($data, $payment_name);
                $link = JRoute::_("index.php?option=com_virtuemart&view=orders&layout=details&order_number=" . $order['details']['BT']->order_number . "&order_pass=" . $order['details']['BT']->order_pass, false);
                $html .= '<br />
        		<a class="vm-button-correct" href="' . $link . '">' . vmText::_('COM_VIRTUEMART_ORDER_VIEW_ORDER') . '</a>';
            } else {
                vmError('Error was occured');
                return;
            }
        } else {
            $virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($order_number);
        }

        $cart = VirtueMartCart::getCart();
        $cart->emptyCart();
        return true;
    }

    function plgVmOnPaymentNotification()
    {


        if (!class_exists('VirtueMartCart'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');

        if (!class_exists('shopFunctionsF'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');

        $data = vRequest::getRequest();

        $response = $this->checkRequest($data);

        if ($response['error'] != 0) {
            $this->sendResponse($response);
        }

        $virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($data['merchant_trans_id']);

        $this->_storeInternalData($virtuemart_order_id, $data);

        try {

            if($data['action'] == CLICK_ACTION_PREPARE) {
                $response = $this->prepare($data, $virtuemart_order_id);
            } else {
                $response = $this->complete($data, $virtuemart_order_id);
            }

        } catch (Exception $ex) {
            $response = array(
                'error' => '-7',
                'error_note' => vmText::_('VMPAYMENT_CLICKUZ_ERROR_UPDATE')
            );
        }

        $this->sendResponse($response);
    }

    function prepare( $data, $virtuemart_order_id ) {
        $orderModel = VmModel::getModel('orders');

        $order = $orderModel->getOrder($virtuemart_order_id);

        $order['customer_notified'] = 1;
        $nb_history = count($order['history']);

        $order['order_status'] = $data['error'] == 0 ? 'P' : 'X';

        if ($order['history'][$nb_history - 1]->order_status_code != $order['order_status']) {
            $orderModel->updateStatusForOneOrder($virtuemart_order_id, $order, true);
        }

        return array(
            'click_trans_id' => $data['click_trans_id'],
            'merchant_trans_id' => $data['merchant_trans_id'],
            'merchant_prepare_id' => $virtuemart_order_id,
            'error' => '0',
            'error_note' => vmText::_('VMPAYMENT_CLICKUZ_SUCCESS')
        );
    }

    function complete($data, $virtuemart_order_id) {
        $orderModel = VmModel::getModel('orders');

        $order = $orderModel->getOrder($virtuemart_order_id);

        $order['customer_notified'] = 1;
        $nb_history = count($order['history']);



        if( $data['error'] == 0 ) {
            if ($order['history'][$nb_history - 1]->order_status_code == $order['order_status']) {
                $orderModel->updateStatusForOneOrder($virtuemart_order_id, $order, true);
            }

            return array(
                'click_trans_id' => $data['click_trans_id'],
                'merchant_trans_id' => $data['merchant_trans_id'],
                'merchant_confirm_id' => $virtuemart_order_id,
                'error' => '0',
                'error_note' => vmText::_('VMPAYMENT_CLICKUZ_SUCCESS')
            );
        } else {
            return array(
                'click_trans_id' => $data['click_trans_id'],
                'merchant_trans_id' => $data['merchant_trans_id'],
                'merchant_confirm_id' => $virtuemart_order_id,
                'error' => '-9',
                'error_note' => vmText::_('VMPAYMENT_CLICKUZ_TRANSACTION_CANCELLED')
            );
        }


    }

    function checkRequest($data)
    {

        if (!isset(
            $data['click_trans_id'],
            $data['service_id'],
            $data['merchant_trans_id'],
            $data['amount'],
            $data['action'],
            $data['sign_time'])) {

            return array(
                'error' => '-8',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_IN_REQUEST')
            );
        }

        if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($data['merchant_trans_id']))) {
            return array(
                'error' => '-5',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_ORDER')
            );
        }

        $orderModel = VmModel::getModel('orders');

        $order = $orderModel->getOrder($virtuemart_order_id);

        if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return array(
                'error' => '-8',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_IN_REQUEST')
            );
        }

        $signString = $data['click_trans_id'] .
            $data['service_id'] .
            $method->click_uz_secret_key .
            $data['merchant_trans_id'] .
            ($data['action'] == 1 ? $data['merchant_prepare_id'] : '') .
            $data['amount'] .
            $data['action'] .
            $data['sign_time'];

        $signString = md5($signString);

        if ($signString !== $data['sign_string']) {
            return array(
                'error' => '-1',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_SIGN')
            );
        }

        if($data['action'] == CLICK_ACTION_COMPLETE && $virtuemart_order_id != $data['merchant_prepare_id']) {
            return array(
                'error' => '-6',
                'error_note' => vmText::_('VMPAYMENT_CLICKUZ_ERROR_TRANSACTION')
            );
        }

        $customer_total = (number_format((float)$order['details']['BT']->order_total, 2, '.', ''));

        if (abs($customer_total - (float)$data['amount']) > 0.01) {
            return array(
                'error' => '-2',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_AMOUNT')
            );
        }

        $nb_history = count($order['history']);
        $status = $order['history'][$nb_history - 1]->order_status_code;

        if ($status == 'C') {
            return array(
                'error' => '-4',
                'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_ERROR_ALREADY_PAID')
            );
        }
        return array(
            'error' => '0',
            'error_note' => vmText::_('VM_PAYMENT_CLICK_UZ_SUCCESS')
        );
    }

    function sendResponse($response)
    {
        echo json_encode($response);
        exit;
    }

    function plgVmOnUserPaymentCancel()
    {

        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');

        $order_number = vRequest::getVar('on');
        if (!$order_number)
            return false;
        $db = JFactory::getDBO();
        $query = 'SELECT ' . $this->_tablename . '.`virtuemart_order_id` FROM ' . $this->_tablename . " WHERE  `order_number`= '" . $order_number . "'";

        $db->setQuery($query);
        $virtuemart_order_id = $db->loadResult();

        if (!$virtuemart_order_id) {
            return null;
        }
        $this->handlePaymentUserCancel($virtuemart_order_id);

        return true;
    }

    function _storeInternalData($virtuemart_order_id, $data)
    {
        $orderModel = VmModel::getModel('orders');

        $order = $orderModel->getOrder($virtuemart_order_id);
        $method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id);
        $fields = array(
            'virtuemart_order_id' => $virtuemart_order_id,
            'order_number' => $data['merchant_trans_id'],
            'virtuemart_paymentmethod_id' => $order['details']['BT']->virtuemart_paymentmethod_id,
            'payment_name' => $this->renderPluginName($method),
            'payment_currency' => $method->payment_curreny,
            'click_response' => json_encode($data),
            'click_paydoc_id' => $data['click_paydoc_id'],
            'click_trans_id' => $data['click_trans_id']
        );

        $this->storePSPluginInternalData($fields, 'virtuemart_order_id', true);
    }

    function _getPaymentResponseHtml($table, $payment_name)
    {

        $html = '<table>' . "\n";
        $html .= $this->getHtmlRow('VMPAYMENT_CLICKUZ_PAYMENT_NAME', $payment_name);
        if (!empty($table)) {
            $html .= $this->getHtmlRow('VMPAYMENT_CLICKUZ_ORDER_NUMBER', $table['order_number']);
            $html .= $this->getHtmlRow('VMPAYMENT_CLICKUZ_AMOUNT', $table['total'] . " " . $table['currency_code']);
            $html .= $this->getHtmlRow('VMPAYMENT_CLICKUZ_RESPONSE_PAYMENT_STATUS', vmText::_ ($table['status']));
        }
        $html .= '</table>' . "\n";

        return $html;
    }

    function _getStatusName($status_code)
    {
        $db = JFactory::getDBO();
        $query = "SELECT `order_status_name` FROM #__virtuemart_orderstates WHERE  `order_status_code`= '{$status_code}'";

        $db->setQuery($query);
        return $db->loadResult();
    }

    function plgVmDeclarePluginParamsPayment($name, $id, &$data) {
        return $this->declarePluginParams('payment', $name, $id, $data);
    }

    function plgVmDeclarePluginParamsPaymentVM3( &$data) {
        return $this->declarePluginParams('payment', $data);
    }

    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {
        return $this->setOnTablePluginParams($name, $id, $table);
    }

}
